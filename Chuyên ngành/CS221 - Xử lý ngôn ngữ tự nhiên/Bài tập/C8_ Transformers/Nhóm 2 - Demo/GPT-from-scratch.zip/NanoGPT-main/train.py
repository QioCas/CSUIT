import argparse
import tiktoken
import torch
import torch.nn.functional as F
from config import GPTConfig, LRSchedulerConfig, TrainingConfig, SamplingConfig, get_model_config
from model.transformer import GPT
from data.loader import DataLoaderLite
from utils.lr_scheduler import LRScheduler
from utils.distributed import ddp_setup, ddp_cleanup
from utils.logger import get_logger
from torch.nn.parallel import DistributedDataParallel as DDP
import torch.distributed as dist
import logging, time, os

SEED = 1337

sampling_config = SamplingConfig()
lr_scheduler_config = LRSchedulerConfig()
training_config = TrainingConfig()
lr_scheduler = LRScheduler(
    max_lr=lr_scheduler_config.max_lr,
    min_lr=lr_scheduler_config.min_lr,
    warmup_steps=training_config.warmup_steps,
    max_steps=training_config.max_steps
)

def save_checkpoint(step, val_loss, is_best: bool = False):
    os.makedirs("checkpoints", exist_ok=True)
    raw_model = model.module if ddp else model
    if hasattr(raw_model, '_orig_mod'):
        raw_model = raw_model._orig_mod
        
    checkpoint = {
        'step': step,
        'model_state_dict': raw_model.state_dict(),
        'optimizer_state_dict': optimizer.state_dict(),
        'val_loss': val_loss,
        'config': raw_model.config
    }
    torch.save(checkpoint, f'checkpoints/model_step_{step:06d}.pt')
    if is_best:
        torch.save(checkpoint, 'checkpoints/model_best.pt')
    

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="NanoGPT Training Script")
    parser.add_argument('--use_torch_compile', action='store_true', help='Use torch.compile for training')
    parser.add_argument('--model_type', type=str, default='gpt2', help='gpt2|gpt2-medium|gpt2-large|gpt2-xl')
    parser.add_argument('--resume', type=str, default=None, help='Path to checkpoint to resume from (e.g., checkpoints/model_step_30.pt)')
    args = parser.parse_args()
        
    ddp, ddp_rank, ddp_local_rank, ddp_world_size, master_process, device = ddp_setup()
    root_logger = get_logger(name="NanoGPT", log_dir="logs", master_process=master_process)
    logger = logging.getLogger(f'NanoGPT.train')
    if master_process:
        logger.info(f'STARTING TRAINING PROCESS')
        logger.info(f"DDP World Size: {ddp_world_size}")
        
    device_type = "cuda" if device.startswith("cuda") else "cpu"
    if master_process:
        logger.info(f"Using device: {device}")
    
    torch.manual_seed(SEED)
    if torch.cuda.is_available():
        torch.cuda.manual_seed(SEED)

    enc = tiktoken.get_encoding("gpt2")
    
    checkpoint = None
    model_config = None
    if args.resume is not None:
        try:
            if master_process:
                logger.info(f"Resuming from checkpoint: {args.resume}")
            torch.serialization.add_safe_globals([GPTConfig])
            checkpoint = torch.load(args.resume, map_location=device)
            model_config = checkpoint['config']
        except Exception as e:
            raise ValueError(f"Failed to load checkpoint from {args.resume}: {e}")
    
    if not model_config:
        model_config = get_model_config(args.model_type, vocab_size=50304)
    
    total_batch_size = training_config.total_batch_size
    B = training_config.B
    T = training_config.T
    assert total_batch_size % (B * T * ddp_world_size) == 0, "Total batch size must be divisible by B * T * ddp_world_size"
    gradient_accumulation_steps = total_batch_size // (B * T * ddp_world_size)
    if master_process:
        logger.info(f"Total Desired Batch Size: {total_batch_size}")
        logger.info(f"Gradient Accumulation Steps: {gradient_accumulation_steps}")

    train_loader = DataLoaderLite(B, T, ddp_rank, ddp_world_size, split='train')
    val_loader = DataLoaderLite(B, T, ddp_rank, ddp_world_size, split='val')

    model = GPT(model_config).to(device)
    if checkpoint:
        model.load_state_dict(checkpoint['model_state_dict'])
        start_step = checkpoint['step'] + 1
        best_val_loss = checkpoint.get('val_loss', float('inf'))
        if master_process:
            logger.info(f"Resumed from step {checkpoint['step']} with validation loss {best_val_loss:.4f}")
    else:
        start_step = 0
        best_val_loss = float('inf')
    
    if args.use_torch_compile:
        if master_process: logger.info("Because using torch.compile, sampling will be skipped during training.")
        model = torch.compile(model)
    if ddp:
        model = DDP(model, device_ids=[ddp_local_rank])
    original_model = model.module if ddp else model
    
    optimizer = original_model.configure_optimizers(
        weight_decay=lr_scheduler_config.weigh_decay,
        learning_rate=lr_scheduler_config.max_lr,
        master_process=master_process,
        device_type=device_type
    )
    
    for step in range(start_step, training_config.max_steps):
        t0 = time.time()
        
        # Calculate validation loss
        if step % 15 == 0:
            model.eval()
            val_loader.reset()
            with torch.no_grad():
                val_loss_accum = 0.0
                val_loss_step = 20
                for _ in range(val_loss_step):
                    x, y = val_loader.next_batch()
                    x, y = x.to(device), y.to(device)
                    with torch.autocast(device_type=device_type, dtype=torch.bfloat16):
                        logits, loss = model(x, y)
                    loss = loss / val_loss_step
                    val_loss_accum += loss.detach()
                if ddp:
                    dist.all_reduce(val_loss_accum, op=dist.ReduceOp.AVG)
                if master_process:
                    logger.info(f"Validation Loss: {val_loss_accum.item():.4f}")
                    if step > 0 and (step % 30 == 0 or step == training_config.max_steps - 1):
                        is_best = val_loss_accum.item() < best_val_loss
                        if is_best:
                            best_val_loss = val_loss_accum.item()
                        save_checkpoint(step, val_loss_accum.item(), is_best)
                        logger.info(f"Checkpoint saved at step {step}. {'(Best so far)' if is_best else ''}")

        # Sampling from the model
        if step > 0 and step % 15 == 0 and not args.use_torch_compile and master_process:
            model.eval()
            tokens = enc.encode(sampling_config.prompt)
            tokens = torch.tensor(tokens, dtype=torch.long).unsqueeze(0).repeat(sampling_config.num_return_sequences, 1)
            xgen = tokens.to(device)
            sample_rng = torch.Generator(device=device).manual_seed(SEED)
            while xgen.size(1) < sampling_config.max_length:
                with torch.no_grad():
                    with torch.autocast(device_type=device_type, dtype=torch.bfloat16):
                        logits, loss = model(xgen)
                    logits = logits[:, -1, :] / sampling_config.temperature
                    probs = F.softmax(logits, dim=-1)
                    topk_probs, topk_indices = torch.topk(probs, k=20, dim=-1)
                    ix = torch.multinomial(topk_probs, num_samples=1, generator=sample_rng)
                    xcol = torch.gather(topk_indices, dim=-1, index=ix)
                    xgen = torch.cat((xgen, xcol), dim=1)
                    
            for i in range(sampling_config.num_return_sequences):
                tokens = xgen[i, :sampling_config.max_length].tolist()
                decoded = enc.decode(tokens)
                logger.info(f"\n=== Sample {i+1} ===\n{decoded}\n")
            
        model.train()
        optimizer.zero_grad()
        loss_accum = 0.0
        for micro_step in range(gradient_accumulation_steps):
            x, y = train_loader.next_batch()
            x, y = x.to(device), y.to(device)
            with torch.autocast(device_type=device_type, dtype=torch.bfloat16):
                logits, loss = model(x, y)
            loss = loss / gradient_accumulation_steps
            loss_accum += loss.detach()
            if ddp:
                model.require_backward_grad_sync = (micro_step == gradient_accumulation_steps - 1)
            loss.backward()
        if ddp:
            dist.all_reduce(loss_accum, op=dist.ReduceOp.AVG)
        norm = torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        lr = lr_scheduler.get_lr(step)
        for param_group in optimizer.param_groups:
            param_group['lr'] = lr
        optimizer.step()
        
        torch.cuda.synchronize() if torch.cuda.is_available() else None
        t1 = time.time()
        dt = (t1 - t0) * 1000
        tokens_per_sec = train_loader.B * train_loader.T * ddp_world_size * gradient_accumulation_steps / (t1 - t0)
        if master_process:
            logger.info(f"Step: {step:5d}| Loss: {loss_accum.item()}| LR: {lr:.2e}| Grad Norm: {norm.item():.2f}| Time: {dt:.2f} ms| Tokens/sec: {tokens_per_sec:.2f}")
            
    if ddp:
        ddp_cleanup()
            
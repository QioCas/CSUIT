import csv
import random
from datetime import datetime, timedelta

"""
Sinh dữ liệu "bẩn" cho bài ETL:
- Header: student_code, full_name, dob, gender_raw, email_raw, phone.
- Giá trị cố ý lẫn lộn (format ngày, giới tính, email hoa/thường) để làm sạch
  trước khi nạp vào bảng staging và chuẩn hóa sang schema chính.
"""

# Cấu hình
NUM_STUDENTS = 1000
OUTPUT_FILE = 'raw_students.csv'

# Dữ liệu mẫu
FIRST_NAMES = ['An', 'Binh', 'Cuong', 'Dung', 'Giang', 'Hanh', 'Hung', 'Khanh', 'Lan', 'Minh', 'Ngan', 'Phuc', 'Quynh', 'Trang', 'Vy']
LAST_NAMES = ['Nguyen', 'Tran', 'Le', 'Pham', 'Hoang', 'Huynh', 'Phan', 'Vu', 'Vo', 'Dang', 'Bui', 'Do']
GENDERS_RAW = ['Nam', 'MALE', 'Male', 'M', 'Nu', 'FEMALE', 'Female', 'F', 'Other', 'Unknown']
EMAILS_DOMAINS = ['gmail.com', 'yahoo.com', 'outlook.com', 'hotmail.com']

def random_date(start_year=2000, end_year=2005):
    start = datetime(start_year, 1, 1)
    end = datetime(end_year, 12, 31)
    return start + timedelta(days=random.randint(0, (end - start).days))

def generate_dirty_dob(date_obj):
    # Tạo ngày tháng "bẩn" với nhiều định dạng
    formats = ['%Y-%m-%d', '%d/%m/%Y', '%d-%m-%Y', '%Y/%m/%d']
    return date_obj.strftime(random.choice(formats))

def generate_data():
    with open(OUTPUT_FILE, 'w', newline='', encoding='utf-8') as f:
        writer = csv.writer(f)
        # Header
        writer.writerow(['student_code', 'full_name', 'dob', 'gender_raw', 'email_raw', 'phone'])

        for i in range(1, NUM_STUDENTS + 1):
            s_code = f'SV{i:05d}'
            f_name = f"{random.choice(LAST_NAMES)} {random.choice(FIRST_NAMES)}"
            dob = generate_dirty_dob(random_date())
            gender = random.choice(GENDERS_RAW)
            
            # Tạo email cá nhân lộn xộn
            email = f"{s_code.lower()}.{random.randint(10,99)}@{random.choice(EMAILS_DOMAINS)}"
            if random.random() < 0.1: email = email.upper() # 10% email viết hoa
            
            phone = f"09{random.randint(10000000, 99999999)}"

            writer.writerow([s_code, f_name, dob, gender, email, phone])
    
    print(f"Đã tạo file {OUTPUT_FILE} với {NUM_STUDENTS} dòng dữ liệu.")

if __name__ == "__main__":
    generate_data()
DROP DATABASE IF EXISTS UniversityDB;
CREATE DATABASE UniversityDB CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE UniversityDB;

-- 1. Bảng Sinh viên
CREATE TABLE Students (
    student_id INT AUTO_INCREMENT PRIMARY KEY,
    student_code VARCHAR(20) NOT NULL UNIQUE,
    full_name VARCHAR(100) NOT NULL,
    birth_date DATE NOT NULL,
    gender ENUM('Male', 'Female', 'Other') NOT NULL,
    email VARCHAR(100) UNIQUE,
    phone VARCHAR(20),
    status ENUM('Active', 'Graduated', 'Suspended') DEFAULT 'Active',
    attributes JSON COMMENT 'Lưu thông tin động: sở thích, chứng chỉ...',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 2. Bảng Môn học
CREATE TABLE Subjects (
    subject_id INT AUTO_INCREMENT PRIMARY KEY,
    subject_code VARCHAR(20) NOT NULL UNIQUE,
    subject_name VARCHAR(100) NOT NULL,
    credits TINYINT UNSIGNED NOT NULL CHECK (credits > 0)
);

-- 3. Bảng Lớp học phần
CREATE TABLE CourseSections (
    section_id INT AUTO_INCREMENT PRIMARY KEY,
    section_code VARCHAR(50) NOT NULL UNIQUE,
    subject_id INT NOT NULL,
    semester ENUM('1', '2', '3') NOT NULL,
    school_year VARCHAR(9) NOT NULL,
    max_capacity INT NOT NULL DEFAULT 40 CHECK (max_capacity > 0),
    FOREIGN KEY (subject_id) REFERENCES Subjects(subject_id)
);

-- 4. Bảng Thời khóa biểu
CREATE TABLE Schedules (
    schedule_id INT AUTO_INCREMENT PRIMARY KEY,
    section_id INT NOT NULL,
    day_of_week TINYINT UNSIGNED NOT NULL CHECK (day_of_week BETWEEN 1 AND 7),
    start_period TINYINT UNSIGNED NOT NULL CHECK (start_period > 0),
    total_periods TINYINT UNSIGNED NOT NULL CHECK (total_periods > 0),
    room_number VARCHAR(20),
    FOREIGN KEY (section_id) REFERENCES CourseSections(section_id) ON DELETE CASCADE
);

-- 5. Bảng Đăng ký (Enrollments)
CREATE TABLE Enrollments (
    enrollment_id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL,
    section_id INT NOT NULL,
    registration_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    score DECIMAL(4, 2) CHECK (score BETWEEN 0 AND 10),
    status ENUM('Registered', 'Passed', 'Failed', 'Canceled') DEFAULT 'Registered',
    FOREIGN KEY (student_id) REFERENCES Students(student_id),
    FOREIGN KEY (section_id) REFERENCES CourseSections(section_id),
    UNIQUE KEY uq_student_section (student_id, section_id)
);
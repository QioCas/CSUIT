#include "iostream"
#include "iomanip"
#include "string"
#include "vector"

using namespace std;

#define print(x) cout << #x << " = " << x << "\n";

class Employee {
protected:
    string id, name, phone, email;
    int age;
    double baseSalary;

public:
    virtual void input() {
        cin >> id; cin.ignore(); 
        getline(cin, name);
        cin >> age; cin.ignore();
        getline(cin, phone);
        getline(cin, email);
        cin >> baseSalary;
    }

    virtual void output() const {
        print(id);
        print(name);
        print(age);
        print(phone);
        print(email);
        cout << "Luong Co ban = " << fixed << setprecision(0) << baseSalary << "\n";
    }

    virtual double calculateSalary() const = 0; 
};


class Programmer : public Employee {
private:
    int overtimeHours;
public:
    void input() override {
        Employee::input();
        cin >> overtimeHours;
    }

    double calculateSalary() const override {
        return baseSalary + overtimeHours * 200000;
    }

    void output() const override {
        
        Employee::output();
        cout << "Lap Trinh Vien:\n";
        print(overtimeHours);
        cout << "Luong = " << fixed << setprecision(0) << calculateSalary() << "\n";
        cout << string(36, '+') << "\n";
    }
};


class Tester : public Employee {
private:
    int bugsFound;
public:
    void input() override {
        Employee::input();
        cin >> bugsFound;
    }

    double calculateSalary() const override {
        return baseSalary + bugsFound * 50000;
    }

    void output() const override {
        Employee::output();
        cout << "Kiem chung vien:\n";
        print(bugsFound);
        cout << "Luong = " << fixed << setprecision(0) << calculateSalary() << "\n";
        cout << string(36, '+') << "\n";
    }
};

int main() {
    vector<Employee*> lst;
    int n; cin >> n;

    cout << "DS nhan vien:\n";

    for(int i = 0; i < n; ++i) {
        int type; cin >> type;  
        Employee* x;
        if(type == 1) {
            // Lap Trinh Vien
            x = new Programmer();
        }
        if(type == 2) {
            // Kiem Chung Vien
            x = new Tester();
        }
        x->input();
        lst.push_back(x);
    }
    
    for(int i = 0; i < n; ++i) {
        lst[i]->output();
    }

    cout << "\n";
    cout << "DS nhan vien thap hon luong trung binh:\n";

    double luongTrungBinh = 0;
    for(int i = 0; i < n; ++i) {
        luongTrungBinh += lst[i]->calculateSalary();
    }
    luongTrungBinh = luongTrungBinh / n;

    for(int i = 0; i < n; ++i) {
        if(lst[i]->calculateSalary() < luongTrungBinh) {
            lst[i]->output();
        }
    }
}
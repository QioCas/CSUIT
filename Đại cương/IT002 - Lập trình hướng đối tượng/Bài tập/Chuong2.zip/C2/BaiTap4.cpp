#include "bits/stdc++.h"
using namespace std;

struct HocSinh {
    string MS, HoTen;
    double Toan, Ly, Hoa;

    HocSinh() = default;
    HocSinh(string MS, string HoTen, double Toan, double Ly, double Hoa):
    MS(MS), HoTen(HoTen), Toan(Toan), Ly(Ly), Hoa(Hoa) {}

    friend istream& operator >> (istream& cin, HocSinh& val) {
        return cin >> val.MS >> val.HoTen >> val.Toan >> val.Ly >> val.Hoa;
    }
    friend ostream& operator << (ostream& cout, const HocSinh& val) {
        cout << "++++++++++++++++++++++\n";
        cout << "Ma hoc sinh: " << val.MS << '\n';
        cout << "Ho Ten: " << val.HoTen << '\n';
        cout << "Diem Toan: " << val.Toan << '\n';
        cout << "Diem Ly: " << val.Ly << '\n';
        cout << "Diem Hoa: " << val.Hoa << '\n';
        cout << "Diem trung binh: " << (val.Toan + val.Ly + val.Hoa) / 3 << '\n';
        cout << "++++++++++++++++++++++\n";
        return cout;
    }
};

int main() {
    HocSinh a; cin >> a;
    cout << a << '\n';
}
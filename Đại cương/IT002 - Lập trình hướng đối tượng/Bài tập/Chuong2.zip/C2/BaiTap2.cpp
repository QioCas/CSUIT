#include "bits/stdc++.h"

using namespace std;
using ll = long long;

struct Fact {
    ll x, y;
    Fact() = default;
    Fact(ll x, ll y): x(x), y(y) { this->RutGon(); }
    void RutGon() {
        assert(y != 0);
        if(x == 0) y = 1;
        if(y < 0) x *= -1, y *= -1;
        
        ll gcd = __gcd(abs(x), abs(y));
        x /= gcd; y /= gcd;
    }
    friend istream& operator >> (istream& cin, Fact& val) {
        cin >> val.x >> val.y;
        val.RutGon();
        return cin;
    }
    friend ostream& operator << (ostream& cout, const Fact& val) {
        return cout << val.x << " / " << val.y;
    }
    friend Fact operator + (const Fact& a, const Fact& b) {
        return Fact(a.x * b.y + b.x * a.y, a.y * b.y);
    }
    friend bool operator<(const Fact& a, const Fact& b) {
        return a.x * b.y < b.x * a.y;
    }
};


int main() {
    int n; cin >> n;
    Fact a[n];
    for(int i = 0; i < n; ++i) {
        cin >> a[i];
    }
    
    Fact sum(0, 1), maxi = a[0];
    for(int i = 0; i < n; ++i) {
        sum = sum + a[i];
    }
    
    for(int i = 0; i < n; ++i) {
        if(maxi < a[i]) {
            maxi = a[i];
        }
    }

    cout << "Tong phan so: " << sum << '\n';
    cout << "Phan so lon nhat: " << maxi << '\n';
}

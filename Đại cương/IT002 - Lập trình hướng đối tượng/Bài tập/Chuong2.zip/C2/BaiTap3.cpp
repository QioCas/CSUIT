#include "bits/stdc++.h"
#include <vector>
using namespace std;
using ll = long long;

struct Matrix {
    vector<vector<ll>> A;
    Matrix() = default;
    Matrix(int numRow, int numCol) {
        A = vector<vector<ll>>(numRow, vector<ll>(numCol));
    }
    
    friend Matrix operator + (const Matrix& a, const Matrix& b) {
        int numRow = a.getNumRow();
        int numCol = a.getNumCol();

        Matrix c(numRow, numCol);
        for(int i = 0; i < numRow; ++i) {
            for(int j = 0; j < numCol; ++j) {
                c[i][j] = a[i][j] + b[i][j];
            }
        }
        return c;
    }

    friend Matrix operator - (const Matrix& a, const Matrix& b) {
        int numRow = a.getNumRow();
        int numCol = a.getNumCol();

        Matrix c(numRow, numCol);
        for(int i = 0; i < numRow; ++i) {
            for(int j = 0; j < numCol; ++j) {
                c[i][j] = a[i][j] - b[i][j];
            }
        }
        return c;
    }

    friend Matrix operator * (const Matrix& a, const Matrix& b) {
        int m = a.getNumRow();
        int n = a.getNumCol();
        int p = b.getNumCol();
        Matrix c(m, p);

        for(int i = 0; i < m; ++i) {
            for(int j = 0; j < p; ++j) {
                for(int k = 0; k < n; ++k) {
                    c[i][j] += a[i][k] * b[k][j];
                }
            }
        }
        return c;
    }

    vector<ll>& operator[] (int i) {
        return A[i];
    }
    vector<ll> operator[] (int i) const {
        return A[i];
    }

    int getNumRow() const {
        return A.size();
    }
    int getNumCol() const {
        return A[0].size();
    }
};

int main() {
    Matrix a(3, 3), b(3, 3);
    for(int i = 0; i < 3; ++i) {
        for(int j = 0; j < 3; ++j) {
            cin >> a[i][j];
        }
    }
    for(int i = 0; i < 3; ++i) {
        for(int j = 0; j < 3; ++j) {
            cin >> b[i][j];
        }
    }
    Matrix Tong = a + b;
    Matrix Hieu = a - b;
    Matrix Tich = a * b;
    cout << "Tong: \n";
    for(int i = 0; i < 3; ++i) {
        for(int j = 0; j < 3; ++j) {
            cout << Tong[i][j] << ' ';
        }
        cout << '\n';
    }

    cout << "Hieu: \n";
    for(int i = 0; i < 3; ++i) {
        for(int j = 0; j < 3; ++j) {
            cout << Hieu[i][j] << ' ';
        }
        cout << '\n';
    }

    cout << "Tich: \n";
    for(int i = 0; i < 3; ++i) {
        for(int j = 0; j < 3; ++j) {
            cout << Tich[i][j] << ' ';
        }
        cout << '\n';
    }
}
#include <bits/stdc++.h>

using namespace std;

mt19937 rd(chrono::steady_clock::now().time_since_epoch().count());

template <class T = int> T randint(T L, T R) { 
    return uniform_int_distribution<T>(L, R) (rd);
}

class cArray : vector<int> {
public:
    cArray() = default;

    void generateRandom(int n, int minVal = 0, int maxVal = 100) {
        this->resize(n);
        for (int& v : (*this)) v = randint(minVal, maxVal);
    }

    // Count occurrences of x
    int countOccur(int x) const {
        return count(this->begin(), this->end(), x);
    }

    // Check if array is sorted in ascending order
    bool isAscending() const {
        for (size_t i = 1; i < this->size(); ++i)
            if ((*this)[i] < (*this)[i - 1]) return false;
        return true;
    }

    // Find the smallest odd element
    int smallestOdd() const {
        int minOdd = numeric_limits<int>::max();
        for (int v : (*this)) {
            if (v % 2 != 0 && v < minOdd) {
                minOdd = v;
            }
        }
        return minOdd;
    }

    // Sort the array in ascending order
    void sortAscending() {
        sort(this->begin(), this->end());
    }

    friend istream& operator>>(istream& cin, cArray& val) {
        int n; cin >> n;
        val.resize(n);
        for (int i = 0; i < n; ++i) {
            cin >> val[i];
        }
        return cin;
    }

    friend ostream& operator<<(ostream& cout, const cArray& val) {
        for(int x : val) cout << x << " ";
        return cout;
    }

};

signed main() {
    cArray arr;

    arr.generateRandom(10, 1, 10);
    cout << arr << "\n";

    int x = 10;
    cout << "Number of occurrences of " << x << ": " << arr.countOccur(x) << "\n";
    cout << "Is array ascending? " << (arr.isAscending() ? "Yes" : "No") << "\n";

    cout << "Smallest odd element: " << arr.smallestOdd() << "\n";

    arr.sortAscending();
    cout << arr << "\n";

    return 0;
}

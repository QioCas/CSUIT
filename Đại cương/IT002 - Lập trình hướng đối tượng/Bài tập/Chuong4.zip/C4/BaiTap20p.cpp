#include <bits/stdc++.h>
using namespace std;
using ll = long long;

class DonThuc {
public:
    double a;
    int b;

    DonThuc() = default;
    DonThuc(double a, int b): a(a), b(b) {}

    friend istream& operator>>(istream& cin, DonThuc& val) {
        cin >> val.a >> val.b;
        return cin;
    }

    friend ostream& operator<<(ostream& cout, const DonThuc& val) {
        if (val.b == 0) cout << val.a;
        else if (val.b == 1) cout << val.a << "x";
        else cout << val.a << "x^" << val.b;
        return cout;
    }

    double get(double x) const {
        return a * pow(x, b);
    }

    DonThuc derivative() const {
        if (b == 0) return DonThuc(0, 0);
        return DonThuc(a * b, b - 1);
    }

    DonThuc operator+(const DonThuc& other) const {
        return DonThuc(a + other.a, b);
    }
};

signed main() {

    DonThuc f1, f2; cin >> f1 >> f2;

    DonThuc sum = f1 + f2;
    cout << "Sum of two monomials: " << sum << "\n";

    return 0;
}

#include <bits/stdc++.h>
using namespace std;
using ll = long long;

mt19937 rng(chrono::steady_clock::now().time_since_epoch().count());
template <class T = int> T randint(T L, T R) {
    return uniform_int_distribution<T>(L, R)(rng);
}

struct Fraction {
    ll x, y;
    Fraction() = default;
    Fraction(ll x, ll y): x(x), y(y) { this->normalize(); }
    void normalize() {
        assert(y != 0);
        if(x == 0) y = 1;
        if(y < 0) x *= -1, y *= -1;
        
        ll gcd = __gcd(abs(x), abs(y));
        if(gcd != 0) { x /= gcd; y /= gcd; }
    }
    friend istream& operator >> (istream& cin, Fraction& val) {
        cin >> val.x >> val.y;
        val.normalize();
        return cin;
    }
    friend ostream& operator << (ostream& cout, const Fraction& val) {
        return cout << val.x << " / " << val.y;
    }
    friend bool operator<(const Fraction& a, const Fraction& b) {
        return (__int128) a.x * b.y < (__int128) b.x * a.y;
    }
};

bool isPrime(int n) {
    if (n < 2) return false;
    for (int i = 2; i * i <= n; ++i)
        if (n % i == 0) return false;
    return true;
}

class arrPhanSo : vector<Fraction> {

public:
    arrPhanSo() = default;

    friend istream& operator>>(istream& cin, arrPhanSo& val) {
        int n;
        cin >> n;
        val.resize(n);
        for (int i = 0; i < n; ++i) {
            cin >> val[i];
        }
        return cin;
    }

    friend ostream& operator<<(ostream& cout, const arrPhanSo& val) {
        for (auto& f : val) cout << f << " ";
        return cout;
    }
    
    void generateRandom(int n, int minVal = -10, int maxVal = 10) {
        this->clear();
        this->reserve(n);
        for (int i = 0; i < n; ++i) {
            int a = randint(minVal, maxVal);
            int b;
            do { b = randint(minVal, maxVal); } while (b == 0);
            this->emplace_back(a, b);
        }
    }

    Fraction maxFraction() const {
        return *max_element(this->begin(), this->end());
    }

    int countNumeratorPrime() const {
        int cnt = 0;
        for (auto& f : (*this))
            if (isPrime(f.x))
                ++cnt;
        return cnt;
    }

    void sortAscending() {
        sort(this->begin(), this->end());
    }
};

signed main() {

    arrPhanSo arr;
    arr.generateRandom(8, -10, 10);

    cout << "List of fractions: " << arr << "\n";
    cout << "Largest fraction: " << arr.maxFraction() << "\n";
    cout << "Fractions with prime numerator: " << arr.countNumeratorPrime() << "\n";

    arr.sortAscending();
    cout << "After sorting ascending: " << arr << "\n";
}

#include <bits/stdc++.h>
using namespace std;

class cBook {
protected:
    string id, name;
    int publishYear, totalPages;

public:
    cBook() = default;
    cBook(string id, string name, int year, int pages)
        : id(id), name(name), publishYear(year), totalPages(pages) {}

    friend istream& operator>>(istream& cin, cBook& b) {
        cin >> ws;
        getline(cin, b.id);
        getline(cin, b.name);
        cin >> b.publishYear >> b.totalPages;
        return cin;
    }

    friend ostream& operator<<(ostream& cout, const cBook& b) {
        cout << "ID: " << b.id
            << ", Name: " << b.name
            << ", Year: " << b.publishYear
            << ", Pages: " << b.totalPages;
        return cout;
    }

    int getYear() const { return publishYear; }
};

class cListBook : public vector<cBook> {
public:
    cListBook() = default;

    friend istream& operator>>(istream& in, cListBook& val) {
        int n; in >> n;
        val.resize(n);
        for (int i = 0; i < n; ++i)
            in >> val[i];
        return in;
    }

    friend ostream& operator<<(ostream& out, const cListBook& val) {
        for (auto& b : val) out << b << "\n";
        return out;
    }

    cBook newestBook() const {
        return *max_element(this->begin(), this->end(), [&] (const cBook& a, const cBook& b) {
            return a.getYear() < b.getYear();
        });
    }
};

signed main() {

    cListBook books;
    cin >> books;

    cout << books;
    cout << "Newest book:\n" << books.newestBook() << "\n";
}

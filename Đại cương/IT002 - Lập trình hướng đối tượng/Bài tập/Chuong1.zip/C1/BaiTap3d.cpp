#include "bits/stdc++.h"
#include <cassert>
#include <memory_resource>

using namespace std;

int last_day[13] = {0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};

int day, month, year; 

void next_year() {
    year++;
}

void next_month() {
    if(month == 12) {
        month = 1;
        next_year();
    } else {
        month++;
    }
}

void next_day() {
    if(day == last_day[month]) {
        day = 1;
        next_month();
    } else {
        day++;
    }
}

int main() {
    // day / month / year
    cin >> day >> month >> year;

    // valid
    assert(1 <= month && month <= 12);

    if(month == 2) {
        if(year % 100 == 0) { if(year % 400 == 0) last_day[2] += 1; }
        else if(year % 4 == 0) last_day[2] += 1;
    }


    assert(1 <= day && day <= last_day[month]);
    next_day();
    printf("%d/%d/%d\n", day, month, year);
}
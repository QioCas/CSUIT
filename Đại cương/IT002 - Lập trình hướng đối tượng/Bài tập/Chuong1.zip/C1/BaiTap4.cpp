#include "bits/stdc++.h"
#include <atomic>
#include <cassert>
#include <istream>

using namespace std;
using ll = long long;

const int N = 100100;

struct NhanVien {
    string MS;
    string HoVaTen; 
    string PhongBan;
    ll LuongCoBan;
    ll Thuong;
    ll ThucLuong;
    
    NhanVien() = default;
    NhanVien(string MS, string HoVaTen, string PhongBan, ll LuongCoBan, ll Thuong): 
    MS(MS), HoVaTen(HoVaTen), PhongBan(PhongBan), LuongCoBan(LuongCoBan), Thuong(Thuong), ThucLuong(LuongCoBan + Thuong) {
        check_valid();
    }
    
    void check_valid() {
        assert(MS.size() <= 8);
        assert(HoVaTen.size() <= 20);
        assert(PhongBan.size() <= 10);

    }

    friend istream& operator >> (istream& cin, NhanVien& val) {
        cin >> val.MS >> val.HoVaTen >> val.PhongBan >> val.LuongCoBan >> val.Thuong;
        val.ThucLuong = val.LuongCoBan + val.Thuong;
        val.check_valid();
        return cin;
    }
    
} lst[N];

int n;

void Problem1() {
    cout << "a)\n";

    ll sum = 0;
    for(int i = 1; i <= n; ++i) {
        sum += lst[i].ThucLuong;
    }
    cout  << "Tong thuc luong cua tat ca nhan vien la " << sum << '\n';
}

void Problem2() {
    cout << "b)\n";

    ll LuongCoBanThapNhat = lst[1].LuongCoBan;
    for(int i = 1; i <= n; ++i) {
        LuongCoBanThapNhat = min(LuongCoBanThapNhat, lst[i].LuongCoBan);
    }
    cout << "Danh sach nhan vien co muc luong co ban thap nhat: \n";
    for(int i = 1; i <= n; ++i) {
        if(LuongCoBanThapNhat == lst[i].LuongCoBan) {
            cout << lst[i].HoVaTen << '\n';
        }
    }
}

void Problem3() {
    cout << "c)\n";
    int count = 0;
    for(int i = 1; i <= n; ++i) {
        if(lst[i].Thuong >= 1200000) {
            ++count;
        }
    }
    cout << "So luong nhan vien co muc thuong >= 1200000 la " << count << '\n';
}

void Problem4() {
    cout << "d)\n";
    sort(lst + 1, lst + n + 1, [&] (const NhanVien& a, const NhanVien& b) {
        if(a.PhongBan != b.PhongBan) return a.PhongBan < b.PhongBan;
        return a.MS > b.MS;
    }); 

    cout << "Danh sach nhan vien tang dan theo phong ban va giam dan theo ma nhan vien: \n";
    for(int i = 1; i <= n; ++i) {
        cout << lst[i].HoVaTen << '\n';
    }
}

int main() {
    cin >> n;
    for(int i = 1; i <= n; ++i) {
        cin >> lst[i];
    }

    Problem1();
    Problem2();
    Problem3();
    Problem4();
}

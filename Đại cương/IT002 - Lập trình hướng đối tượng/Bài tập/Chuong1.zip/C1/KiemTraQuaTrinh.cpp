#include "bits/stdc++.h"
using namespace std;

struct HocSinh {
    string MS, HoTen;
    double Toan, Van, Ly, Hoa;

    HocSinh() = default;
    HocSinh(string MS, string HoTen, double Toan, double Van, double Ly, double Hoa):
    MS(MS), HoTen(HoTen), Toan(Toan), Van(Van), Ly(Ly), Hoa(Hoa) {}

    friend istream& operator >> (istream& cin, HocSinh& val) {
        return cin >> val.MS >> val.HoTen >> val.Toan >> val.Van >> val.Ly >> val.Hoa;
    }
    friend ostream& operator << (ostream& cout, const HocSinh& val) {
        cout << "++++++++++++++++++++++\n";
        cout << "Ma hoc sinh: " << val.MS << '\n';
        cout << "Ho Ten: " << val.HoTen << '\n';
        cout << "Diem Toan: " << val.Toan << '\n';
        cout << "Diem Van: " << val.Van << '\n';
        cout << "Diem Ly: " << val.Ly << '\n';
        cout << "Diem Hoa: " << val.Hoa << '\n';
        cout << "Diem trung binh: " << (val.Toan + val.Van + val.Ly + val.Hoa) / 4 << '\n';
        cout << "++++++++++++++++++++++\n";
        return cout;
    }
};

int main() {
    HocSinh a; cin >> a;
    cout << a << '\n';
}
#include <bits/stdc++.h>

using namespace std;
using ll = long long;

struct Fact {
    ll x, y;
    Fact() = default;
    Fact(ll x, ll y): x(x), y(y) {}
    void RutGon() {
        assert(y != 0);
        if(x == 0) y = 1;
        if(y < 0) x *= -1, y *= -1;
        
        ll gcd = __gcd(abs(x), abs(y));
        x /= gcd; y /= gcd;
    }
    friend istream& operator >> (istream& cin, Fact& val) {
        return cin >> val.x >> val.y;
    }
    friend ostream& operator << (ostream& cout, const Fact& val) {
        return cout << val.x << " / " << val.y;
    }
};

int main() {
    Fact a; cin >> a;
    a.RutGon();
    cout << a << "\n";
}
#include "bits/stdc++.h"

using namespace std;
using ll = long long;

struct Fact {
    ll x, y;
    Fact() = default;
    Fact(ll x, ll y): x(x), y(y) { this->RutGon(); }
    void RutGon() {
        assert(y != 0);
        if(x == 0) y = 1;
        if(y < 0) x *= -1, y *= -1;
        
        ll gcd = __gcd(abs(x), abs(y));
        x /= gcd; y /= gcd;
    }
    friend istream& operator >> (istream& cin, Fact& val) {
        cin >> val.x >> val.y;
        val.RutGon();
        return cin;
    }
    friend ostream& operator << (ostream& cout, const Fact& val) {
        return cout << val.x << " / " << val.y;
    }
    friend Fact operator + (const Fact& a, const Fact& b) {
        return Fact(a.x * b.y + b.x * a.y, a.y * b.y);
    }
    friend Fact operator - (const Fact& a, const Fact& b) {
        return Fact(a.x * b.y - b.x * a.y, a.y * b.y);
    }
    friend Fact operator * (const Fact& a, const Fact& b) {
        return Fact(a.x * b.x, a.y * b.y);
    }
    friend Fact operator / (const Fact& a, const Fact& b) {
        return Fact(a.x * b.y, a.y * b.x);
    }
};


int main() {
    Fact a, b; cin >> a >> b;

    cout << "Tong : " << a + b << '\n';
    cout << "Hieu : " << a - b << '\n';
    cout << "Tich : " << a * b << '\n';
    cout << "Thuong : " << a / b << '\n';
}

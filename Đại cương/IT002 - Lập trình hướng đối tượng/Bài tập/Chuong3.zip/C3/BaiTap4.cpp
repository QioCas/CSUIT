#include "bits/stdc++.h"

using namespace std;

class cArray {
private:
    int length;
    int* a;
public:
    cArray() = default;
    cArray(int n) {
        a = new int[n];
        length = n;
        for(int i = 0; i < n; ++i) {
            a[i] = -10 + (rand()) % 20;
        }
    }

    friend ostream& operator << (ostream& cout, cArray val) {
        for(int i = 0; i < val.length; ++i) {
            cout << val[i] << " ";
        }
        return cout;
    }
    int findMaxNegVal() {
        int ans = -1e9;
        for(int i = 0; i < length; ++i) {
            if(a[i] < 0) ans = max(ans, a[i]);
        }
        return ans;
    }
    int count(int x) {
        int sum = 0;
        for(int i = 0; i < length; ++i) {
            sum += (a[i] == x);
        }
        return sum;
    }
    bool checkDec() {
        for(int i = 1; i < length; ++i) {
            if(a[i - 1] < a[i]) return false;
        }
        return true;
    }
    void sort() {
        std::sort(a, a + length);
    }
    int& operator[] (int idx) {
        assert(idx >= 0 && idx < length);
        return a[idx];
    }
};

int main() {
    cArray a(10);
    cout << a.count(2) << '\n';
    cout << a.findMaxNegVal() << '\n';
    cout << a.checkDec() << '\n';
    a.sort();
    cout << a << '\n';
}
#include "bits/stdc++.h"

using namespace std;

class cHocSinh {
private:
    int ms;
    string name, sex;
    int year;
    double avg;
public:
    cHocSinh() = default;
    cHocSinh(int ms, string name, string sex, int year, double avg):
    ms(ms), name(name), sex(sex), year(year), avg(avg) {}
    friend istream& operator >> (istream& cin, cHocSinh& val) {
        return cin >> val.ms >> val.name >> val.sex >> val.year >> val.avg;
    }
    bool smaller(const cHocSinh& val) {
        return year > val.year;
    }
    bool worse(const cHocSinh& val) {
        return avg < val.avg;
    }
};

int main() {
    
}
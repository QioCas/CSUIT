#include "bits/stdc++.h"

using namespace std;

class Point {
private:
    double x, y;
public:
    Point() = default;
    Point(double x, double y): x(x), y(y) {}
    friend istream& operator >> (istream& cin, Point& val) {
        return cin >> val.x >> val.y;
    }
    #define sq(x) (x) * (x)
    double getDistance(const Point& val) {
        return sqrt(sq(val.x - x) + sq(val.y - y));
    }
    #undef sq
};

int main() {
    Point x, y; cin >> x >> y;
    cout << x.getDistance(y) << '\n';
}
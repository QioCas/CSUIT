#include "bits/stdc++.h"

using namespace std;

const double PI = acos(-1);
class Circle {
private:
    double x, y, r;
public:
    Circle() = default;
    Circle(double x, double y, double r): x(x), y(y), r(r) {}
    friend istream& operator >> (istream& cin, Circle& val) {
        return cin >> val.x >> val.y >> val.r;
    }
    double dienTich() {
        return PI * r * r;
    }
    double chuVi() {
        return 2.00 * PI * r;
    }
};

int main() {
    Circle val; cin >> val;
    cout << val.dienTich() << " " << val.chuVi() << '\n';
}
#include "bits/stdc++.h"

using namespace std;

class cPhanSo {
private:
    int64_t tu, mau;
    void fix() {
        assert(mau != 0);
        if(mau < 0) tu *= -1, mau *= -1;

        int64_t gcd = __gcd(abs(tu), abs(mau));
        tu /= gcd, mau /= gcd;
    }
public:
    cPhanSo(): tu(0), mau(1) {}
    cPhanSo(int64_t tu, int64_t mau): tu(tu), mau(mau) { fix(); }
    friend istream& operator >> (istream& cin, cPhanSo& val) {
        cin >> val.tu >> val.mau;
        val.fix();
        return cin;
    }
    friend ostream& operator << (ostream& cout, cPhanSo val) {
        if(val.mau == 1) return cout << val.tu;
        return cout << val.tu << " / " << val.mau;
    }
    double getValue() {
        return 1.00 * tu / mau;
    }

    cPhanSo operator + (cPhanSo val) {
        tu = tu * val.mau + mau * val.tu;
        mau = mau * val.mau;
        fix();
        return (*this);
    } 

};

int main() {
}
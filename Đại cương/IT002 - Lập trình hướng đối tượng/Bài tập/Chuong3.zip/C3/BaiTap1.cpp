#include "bits/stdc++.h"

using namespace std;

class cHocSinh {
private:
    string name;
    int math, liter;
public:
    cHocSinh() = default;
    cHocSinh(string name, int math, int liter): name(name), math(math), liter(liter) {}
    double avg() const {
        return 1.00 * (math + liter) * 0.5;
    }
    string getRank() {
        double average = avg();
        if(average < 0 || average > 10) return "Khong xac dinh";
        if(average < 5.00) return "Yeu";
        if(average < 6.50) return "Trung binh";
        if(average < 8.00) return "Kha";
        if(average < 9.00) return "Gioi";
        return "Xuat Sac";
    }
    friend istream& operator >> (istream& cin, cHocSinh& val) {
        return cin >> val.name >> val.math >> val.liter;
    }
    friend ostream& operator << (ostream& cout, const cHocSinh& val) {
        cout << "++++++++++++++++++++++\n";
        cout << "Ho va Ten: " << val.name << '\n';
        cout << "Diem Toan: " << val.math << '\n';
        cout << "Diem Hoa: " << val.liter << '\n';
        cout << "Diem trung binh: " << val.avg() << '\n';
        cout << "++++++++++++++++++++++\n";
        return cout;
    }
};

int main() {
    cHocSinh a; cin >> a;
    cout << a << '\n';
}
#include <iostream>
#include <random>
#include <vector>
using namespace std;
using ll = long long;

mt19937 rng(time(NULL));
int randint(int l, int r) {
    return uniform_int_distribution<int> (l, r) (rng);
}

struct Matrix {
    vector<vector<ll>> A;
    Matrix() = default;
    Matrix(int numRow, int numCol) {
        A = vector<vector<ll>>(numRow, vector<ll>(numCol));
    }

    Matrix random(int numRow, int numCol) {
        *this = Matrix(numRow, numCol);
        for(int i = 0; i < numRow; ++i)
        for(int j = 0; j < numCol; ++j)
            (*this)[i][j] = randint(-100, 100);
        return *this;
    }
    friend istream& operator >> (istream& cin, Matrix& val) {
        int numRow = val.getNumRow();
        int numCol = val.getNumCol();
        for(int i = 0; i < numRow; ++i)
            for(int j = 0; j < numCol; ++j)
                cin >> val[i][j];
        return cin;
    }

    friend ostream& operator << (ostream& cout, Matrix val) {
        int numRow = val.getNumRow();
        int numCol = val.getNumCol();
        for(int i = 0; i < numRow; ++i)
            for(int j = 0; j < numCol; ++j)
                cout << val[i][j] << " \n"[j == numCol - 1];
        return cout;
    }

    
    friend Matrix operator + (const Matrix& a, const Matrix& b) {
        int numRow = a.getNumRow();
        int numCol = a.getNumCol();

        Matrix c(numRow, numCol);
        for(int i = 0; i < numRow; ++i) {
            for(int j = 0; j < numCol; ++j) {
                c[i][j] = a[i][j] + b[i][j];
            }
        }
        return c;
    }

    friend Matrix operator - (const Matrix& a, const Matrix& b) {
        int numRow = a.getNumRow();
        int numCol = a.getNumCol();

        Matrix c(numRow, numCol);
        for(int i = 0; i < numRow; ++i) {
            for(int j = 0; j < numCol; ++j) {
                c[i][j] = a[i][j] - b[i][j];
            }
        }
        return c;
    }

    friend Matrix operator * (const Matrix& a, const Matrix& b) {
        int m = a.getNumRow();
        int n = a.getNumCol();
        int p = b.getNumCol();
        Matrix c(m, p);

        for(int i = 0; i < m; ++i) {
            for(int j = 0; j < p; ++j) {
                for(int k = 0; k < n; ++k) {
                    c[i][j] += a[i][k] * b[k][j];
                }
            }
        }
        return c;
    }

    vector<ll>& operator[] (int i) {
        return A[i];
    }
    vector<ll> operator[] (int i) const {
        return A[i];
    }

    int getNumRow() const {
        return A.size();
    }
    int getNumCol() const {
        return A[0].size();
    }
};

int main() {
    Matrix a(3, 3), b(3, 3);
    cin >> a >> b;
    cout << "a + b = \n";
    cout << (a + b) << "\n";
    cout << "a - b = \n";
    cout << (a - b) << "\n";

    Matrix randomMatrix;
    randomMatrix.random(3, 3);
    cout << "Random Matrix[3][3] = \n";
    cout << randomMatrix << "\n";

}
#include <iostream>
#include <random>

using namespace std;
using ll = long long;

mt19937 rng(time(NULL));
int randint(int l, int r) {
    return uniform_int_distribution<int> (l, r) (rng);
}

class DaThuc {
public:
    vector<double> coef; 

    DaThuc() { coef = {0}; }
    DaThuc(int deg) { coef.assign(deg + 1, 0); }

    DaThuc NgauNhien(int deg) {
        coef.assign(deg + 1, 0);
        for(int i = 0; i <= deg; ++i)
            coef[i] = randint(-100, 100);
        return *this;
    }

    int degree() const {
        return (int)coef.size() - 1;
    }

    friend istream& operator>>(istream& cin, DaThuc& p) {
        int n; cin >> n;
        p.coef.resize(n + 1);
        for (int i = 0; i <= n; ++i)
            cin >> p.coef[i];
        return cin;
    }

    friend ostream& operator<<(ostream& cout, const DaThuc& p) {
        int n = p.degree();
        bool printed = false;
        for (int i = 0; i <= n; ++i) {
            double a = p.coef[i];
            int power = n - i;
            if (a == 0) continue;
            if (i > 0 && a > 0) cout << "+";
            if (power == 0) cout << a;
            else if (power == 1) cout << a << "x";
            else cout << a << "x^" << power;
            printed = true;
        }
        if(!printed) cout << 0;
        return cout;
    }

    double get(double x) const {
        double res = 0;
        for (double a : coef)
            res = res * x + a;
        return res;
    }

    DaThuc operator+ (const DaThuc& other) const {
        int n = max(degree(), other.degree());
        vector<double> A = coef, B = other.coef;
        if ((int)A.size() < n + 1) A.insert(A.begin(), n + 1 - A.size(), 0);
        if ((int)B.size() < n + 1) B.insert(B.begin(), n + 1 - B.size(), 0);

        DaThuc res;
        res.coef.resize(n + 1);
        for (int i = 0; i <= n; ++i)
            res.coef[i] = A[i] + B[i];
        return res;
    }

    DaThuc operator- (const DaThuc& other) const {
        int n = max(degree(), other.degree());
        vector<double> A = coef, B = other.coef;
        if ((int)A.size() < n + 1) A.insert(A.begin(), n + 1 - A.size(), 0);
        if ((int)B.size() < n + 1) B.insert(B.begin(), n + 1 - B.size(), 0);

        DaThuc res;
        res.coef.resize(n + 1);
        for (int i = 0; i <= n; ++i)
            res.coef[i] = A[i] - B[i];
        return res;
    }
};

signed main() {

    DaThuc P1, P2;
    cin >> P1;
    cin >> P2;

    cout << "P1(x) = " << P1 << "\n";
    cout << "P2(x) = " << P2 << "\n";

    DaThuc add = P1 + P2;
    DaThuc minus = P1 - P2;

    cout << "P1 + P2 = " << add << "\n";
    cout << "P1 - P2 = " << minus << "\n";
    DaThuc DaThucRandom;
    DaThucRandom.NgauNhien(3);
    cout << DaThucRandom << "\n";
}

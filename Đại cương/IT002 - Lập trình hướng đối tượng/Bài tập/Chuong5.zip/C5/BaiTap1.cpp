#include <iostream>

using namespace std;

class Complex {
private:
    double real, image;
public:
    Complex() = default;
    Complex(double real, double image): real(real), image(image) {}
    void set(double real, double image) {
        this->real = real;
        this->image = image;
    }
    double getReal() {
        return real;
    }
    double getImage() {
        return image;
    }
    friend istream& operator >> (istream& cin, Complex& val) {
        return cin >> val.real >> val.image;
    }
    friend ostream& operator << (ostream& cout, const Complex& val) {
        return cout << val.real << " " << "+-"[val.image < 0] << " " << abs(val.image) << "i";
    }

    friend Complex operator + (Complex a, Complex b) {
        return {a.real + b.real, a.image + b.image};
    }
    friend Complex operator - (Complex a, Complex b) {
        return {a.real - b.real, a.image - b.image};
    }
    friend Complex operator * (Complex a, Complex b) {
        return {a.real * b.real - a.image * b.image, a.real * b.image + a.image * b.real};
    }
    friend Complex operator / (Complex a, Complex b) {
        return {(a.real * b.real + a.image * b.image) / (b.image * b.image + b.real * b.real),
        (b.real * a.image - a.real * b.image)/ (b.image * b.image + b.real * b.real) };
    }
    friend bool operator == (Complex a, Complex b) {
        return a.real == b.real && a.image == b.image;
    }
};

int main() {
    Complex a, b; cin >> a >> b;
    cout << a + b << '\n';
    cout << a - b << '\n';
    cout << a * b << '\n';
    cout << a / b << '\n';
    cout << ((a == b) ? "YES\n" : "NO\n");
}
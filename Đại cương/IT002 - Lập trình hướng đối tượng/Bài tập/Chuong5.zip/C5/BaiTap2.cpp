#include <iostream>
#include <assert.h>
#include <algorithm>

using namespace std;


class PhanSo {
private:
    int tuso;
    int mauso;
public:
    PhanSo(int t = 0, int m = 1): tuso(t), mauso(m) { ChuanHoa(); }
    PhanSo(const PhanSo& p) : tuso(p.tuso), mauso(p.mauso) { ChuanHoa(); }
    int LayTu() { return tuso; }
    int LayMau() { return mauso; }
    void GanTu(int t) { tuso = t; }
    void GanMau(int m) { mauso = m; }
    void Nhap() { cin >> tuso >> mauso; }
    void Xuat() { cout << tuso << " / " << mauso; }
    bool operator > (PhanSo other) {
        ChuanHoa(); 
        other.ChuanHoa();
        return 1ll * tuso * other.LayMau() > 1ll * mauso * other.LayTu();
    }

    PhanSo operator + (PhanSo other) {
        ChuanHoa();
        other.ChuanHoa();
        tie(tuso, mauso) = pair<int, int>{tuso * other.LayMau() + mauso * other.LayTu(), mauso * other.LayMau()};
        ChuanHoa();
        return *this;
    }
    
    PhanSo operator - (PhanSo other) {
        ChuanHoa();
        other.ChuanHoa();
        tie(tuso, mauso) = pair<int, int>{tuso * other.LayMau() - mauso * other.LayTu(), mauso * other.LayMau()};
        ChuanHoa();
        return *this;
    }
    
    void ChuanHoa() {
        assert(mauso != 0);
        if(mauso < 0) tuso *= -1, mauso *= -1;
        int gcd = __gcd(abs(tuso), abs(mauso));
        tuso /= gcd;
        mauso /= gcd;
    }
};

class DSPhanSo {
private:
    PhanSo* arr;
    int sz = 0;
public:
    void GanKichThuoc(int n) {
        sz = n;
        arr = new PhanSo[sz];
    }

    void Nhap() {
        for(int i = 0; i < sz; ++i) 
            arr[i].Nhap();
    }


    PhanSo TimPhanSoLonNhat() {
        PhanSo PhanSoLonNhat = arr[0];
        for(int i = 1; i < sz; ++i) 
            if(arr[i] > PhanSoLonNhat) PhanSoLonNhat = arr[i];
        return PhanSoLonNhat;
    }

    PhanSo TongPhanSo() {
        PhanSo Tong = PhanSo();
        for(int i = 0; i < sz; ++i) 
            Tong = Tong + arr[i];
        return Tong;
    }
};

int main() {
    int n; cin >> n;
    DSPhanSo a;
    a.GanKichThuoc(n);
    a.Nhap();
    a.TimPhanSoLonNhat().Xuat();
}
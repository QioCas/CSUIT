#include "iostream"
#include "string.h"
#include "vector"
#include "iomanip"
#include "algorithm"
using namespace std;

class Employee {
protected:
    string name;
    string birthday;
    double baseSalary;
public:
    virtual double calculateSalary() const = 0;

    virtual void input() {
        cin.ignore();
        getline(cin, name);
        getline(cin, birthday);
        cin >> baseSalary;
    }


    virtual void output() {
        cout << "Ten : " << name << '\n';
        cout << "Ngay sinh : " << birthday << "\n";
    }

    bool kiemTraTen(string name) {
        return (this->name == name);
    }
};

class QuanLy : public Employee {
private:
    double heSoChucVu;
    double thuong;
    void input() {
        Employee::input();
        cin >> heSoChucVu;
        cin >> thuong;
    }

public:
    double calculateSalary() const {
        return baseSalary * heSoChucVu + thuong;
    }

    void output() {
        Employee::output();
        cout << fixed << setprecision(2) << "Luong : " << calculateSalary() << '\n';
    }
};


class SanXuat : public Employee {
private:
    double soSanPham;
    void input() {
        Employee::input();
        cin >> soSanPham;
    }

public:
    double calculateSalary() const {
        return baseSalary + soSanPham * 2000;
    }

    void output() {
        Employee::output();
        cout << fixed << setprecision(2) << "Luong : " << calculateSalary() << '\n';
    }
};


class vanPhong : public Employee {
private:
    double soNgayLam;
    double troCap;

    void input() {
        Employee::input();
        cin >> soNgayLam >> troCap;
    }

public:
    double calculateSalary() const {
        return baseSalary + soNgayLam * 200000 + troCap;
    }

    void output() {
        Employee::output();
        cout << fixed << setprecision(2) << "Luong : " << calculateSalary() << '\n';
    }
};


int main() {
    int n; cin >> n;
    Employee* danhSach[n];

    for(int i = 0; i < n; ++i) {
        int type; cin >> type;
        if(type == 1) danhSach[i] = new QuanLy();
        if(type == 2) danhSach[i] = new SanXuat();
        if(type == 3) danhSach[i] = new vanPhong();
        danhSach[i]->input();
    }

    cout << "Danh sach:\n";
    for(int i = 0; i < n; ++i) {
        danhSach[i]->output();
    }


    double tongLuongCongTy = 0;
    for(int i = 0; i < n; ++i) {
        tongLuongCongTy += danhSach[i]->calculateSalary();
    }

    cout << fixed << setprecision(2) << tongLuongCongTy << '\n';

    string tenCanTimKiem;
    cin.ignore();
    getline(cin, tenCanTimKiem);
    
    cout << "Danh sach co ten can tim kiem:\n";
    for(int i = 0; i < n; ++i) 
        if(danhSach[i]->kiemTraTen(tenCanTimKiem)) {
            danhSach[i]->output();
        }
}
#ifndef VANGNHANTRON
#define VANGNHANTRON 1

#include "VangTa.h"

class VangNhanTron : public VangTa {
private:
    int tienCongCheTac;
public:
    int getTienCongCheTac() { return tienCongCheTac; }
    VangNhanTron() {
        type = 2;
        K = 24;
        giaMua = 14980;
        giaBan = 15280;
        trongluong = randint(1, 5);
        thuonghieu = "DOJI";
        nhaSanXuat = "Viet Nam";
        tienCongCheTac = randint(1, 100);
        thueGTGTvaKhoanThu = randint(1, 100);
    }
};
#endif
#include <iostream>

using namespace std;

#include "random"

mt19937 rng(time(NULL));

int randint(int l, int r) {
    return uniform_int_distribution<int>(l, r)(rng);
}


#include "HoaDon.h"
#include "VangMieng.h"
#include "VangNhanTron.h"
#include "Vang999.h"
#include "VangTay.h"
#include "map"

string name[] = {"Nguyen Van A", "Tran Thi B", "Le Van C", "Pham Thi D", "Hoang Van E"};
double K_values[] = {22, 18, 16.3, 15.6, 14.6, 14};
int main() {
    // Ghi nhan Hoa Don
    int n = 3;
    HoaDon hoaDonList[n];
    for(int i = 0; i < n; ++i) {
        int type; cin >> type;
        string tenCuaHang = "ABC";
        string diaChiNguoiBan = "123 Le Loi, Q1, TP.HCM";
        string maSoThueNguoiBan = "0123456789";
        string tenNguoiMua = name[randint(0, 4)];
        string diaChiNguoiMua = "456 Nguyen Trai, Q5, TP.HCM";
        string CMNDnguoiMua = "xxxxxxxxxxx";
        string ngaythangnam = "01/01/2024";
        string chukiso = "abcxyz";
        VangThat* vang = nullptr;
        if(type == 1) {
            vang = new VangMieng();
        } else if(type == 2) {
            vang = new VangNhanTron();
        } else if(type == 3) {
            vang = new Vang999();
        } else if(type == 4) {
            double K = K_values[randint(0, 5)];
            vang = new VangTay(K);
        }

        hoaDonList[i] = HoaDon{tenCuaHang, diaChiNguoiBan, maSoThueNguoiBan, tenNguoiMua, vang, 0, ngaythangnam, chukiso};

    }
    // Tong gam vang theo tung phan loai 
    double tongTien[10];
    for(int i = 0; i < n; ++i) {
        tongTien[hoaDonList[i].getVang()->getType()] += hoaDonList[i].getTongGiaTriThanhToan();
    }

    map<string, double> mp;
    for(int i = 0; i < n; ++i) {
        mp[hoaDonList[i].getTenNguoiMua()] += hoaDonList[i].getTongGiaTriThanhToan();
    }
    string name_largest = "";
    for(auto it : mp) {
        name_largest = it.first;;
    }
}
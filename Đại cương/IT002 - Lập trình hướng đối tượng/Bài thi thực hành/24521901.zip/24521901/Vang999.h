#ifndef VANG999
#define VANG999 1

#include "VangThat.h"

// Vang999 aka Vang 24K. Trong truong hop nay cu the la vang trang suc.
class Vang999 : public VangThat {
private:
    int tienCongCheTac;
public:
    int getTienCongCheTac() { return tienCongCheTac; }
    Vang999() {
        type = 3;
        K = 24;
        giaMua = 14980;
        giaBan = 15280;
        trongluong = randint(1, 5);
        thuonghieu = "DOJI";
        nhaSanXuat = "Viet Nam";
        tienCongCheTac = randint(1, 100);
        thueGTGTvaKhoanThu = randint(1, 100);
    }
};

#endif
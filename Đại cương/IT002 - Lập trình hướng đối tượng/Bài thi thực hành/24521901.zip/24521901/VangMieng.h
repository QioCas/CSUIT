#ifndef VANGMIENG
#define VANGMIENG 1

#include "VangTa.h"

class VangMieng : public VangTa {
private:
public:
    VangMieng() {
        type = 1;
        K = 24;
        giaMua = 15220;
        giaBan = 15420;
        trongluong = randint(1, 5);
        thuonghieu = "DOJI";
        nhaSanXuat = "Viet Nam";
        thueGTGTvaKhoanThu = randint(1, 100);
    }
};
#endif


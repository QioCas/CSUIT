
#include "VangThat.h"

// VangTay la cac loai vang co K < 24
class VangTay : public VangThat {
private:
    int tienCongCheTac;
public:
    int getTienCongCheTac() { return tienCongCheTac; }
    VangTay() = default;
    VangTay(double K) {
        type = 4;
        this->K = K;
        if(K == 22) {
            type = 4;
            giaMua = 13230;
            giaBan = 13850;
        } else if(K == 18) {
            type = 5;
            giaMua = 10410;
            giaBan = 11340;
        } else if(K == 16.3) {
            type = 6;
            giaMua = 9352;
            giaBan = 10282;
        } else if(K == 15.6) {
            type = 7;
            giaMua = 8898;
            giaBan = 9288;
        } else if(K == 14.6) {
            type = 8;
            giaMua = 8293;
            giaBan = 9223;
        } else if(K == 14) {
            type = 9;
            giaMua = 9715;
            giaBan = 8845;
        } else {
        }
        trongluong = randint(1, 5);
        thuonghieu = "DOJI";
        nhaSanXuat = "Viet Nam";
        tienCongCheTac = randint(1, 100);
        thueGTGTvaKhoanThu = randint(1, 100);
    }
};
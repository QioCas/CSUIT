#ifndef HOADON
#define HOADON 1 

#include "VangThat.h"

#include "string.h"

using namespace std;

class HoaDon {
private:
    string tenCuaHang;
    string diacChiNguoiBan;
    string maSoThueNguoiBan;
    string tenNguoiMua;
    string diaChiNguoiMua;
    string CMNDnguoiMua;
    VangThat* vang;
    long long tongGiaTriThanhToan;
    string ngaythangnam;
    string chukiso;
public:
    HoaDon() = default;
    HoaDon(string tenCuaHang, string diaChiNguoiBan, string maSoThueNguoiBan,
           string tenNguoiMua, VangThat* vang, long long tongGiaTriThanhToan, string ngaythangnam, string chukiso) {
        this->tenCuaHang = tenCuaHang;
        this->diacChiNguoiBan = diaChiNguoiBan;
        this->maSoThueNguoiBan = maSoThueNguoiBan;
        this->tenNguoiMua = tenNguoiMua;
        this->vang = vang;
        this->tongGiaTriThanhToan = tongGiaTriThanhToan;
        this->ngaythangnam = ngaythangnam;
        this->chukiso = chukiso;
    }
    string getTenNguoiMua() { return tenNguoiMua; }
    VangThat* getVang() { return vang; }
    long long getTongGiaTriThanhToan() { return vang->getGiaBan(); }
    // template<class T> T getStat(int i);
};

#endif
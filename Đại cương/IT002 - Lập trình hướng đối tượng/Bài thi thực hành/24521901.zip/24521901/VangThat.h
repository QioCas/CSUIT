#ifndef VANGTHAT
#define VANGTHAT 1 

class VangThat {
protected:
    int type;
    int K;
    int trongluong;
    int giaBan;
    int giaMua;
    int thueGTGTvaKhoanThu;
    string thuonghieu;
    string nhaSanXuat;
public:
    int getGiaMua() { return giaMua * trongluong; }
    int getGiaBan() { return giaBan * trongluong; }
    int getThue() { return thueGTGTvaKhoanThu; }
    int getK() { return K; }
    int getType() { return type; }
    int getTrongLuong() { return trongluong; }
    // template<class T> T getStat(int i);
};

#endif
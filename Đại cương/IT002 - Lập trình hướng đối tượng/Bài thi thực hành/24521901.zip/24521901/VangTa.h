#ifndef VANGTA
#define VANGTA 1

#include "VangThat.h"

class VangTa : public VangThat { };

#endif
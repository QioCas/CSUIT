import polars as pl
import re

# ── Letter-size ordering and thresholds ──────────────────────────────────────
# S=1, M=2, L=3, XL=4, XXL=5
LETTER_ORDER: dict[str, int] = {"S": 1, "M": 2, "L": 3, "XL": 4, "XXL": 5}


def _numeric_to_letter(n: float) -> str:
    """Generic numeric size → S/M/L/XL/XXL (even buckets, all item types treated equally)."""
    if n <= 3:   return "S"
    if n <= 16:  return "M"
    if n <= 24:  return "L"
    if n <= 40:  return "XL"
    return "XXL"


def _area_to_letter(area: float) -> str:
    """Dimension area (cm²) → S/M/L/XL/XXL."""
    if area <= 800:   return "S"
    if area <= 1200:  return "M"
    if area <= 4000:  return "L"
    if area <= 8000:  return "XL"
    return "XXL"


def parse_size(s) -> tuple[str, str | None, float | None]:
    """
    Returns (category, normalized_letter, sort_key).
      category         : 'size' | 'piece' | 'unknown'
      normalized_letter: 'S'/'M'/'L'/'XL'/'XXL' for 'size' cat, else None
      sort_key         : numeric used for ranking
    Note: 'step' category is assigned later from description only.
    """
    if s is None:
        return ("unknown", None, None)
    raw = str(s).strip()
    if not raw or raw == "Không xác định":
        return ("unknown", None, None)

    # ── PIECE — anything containing "miếng" ──────────────────────────────────
    if "miếng" in raw:
        m = re.search(r"(\d+)\s*\+\s*(\d+)\s*miếng", raw)
        if m:
            n = float(int(m.group(1)) + int(m.group(2)))
        else:
            m = re.search(r"(\d+)\s*miếng", raw)
            n = float(int(m.group(1))) if m else 0.0
        return ("piece", None, n)

    # ── SIZE ─────────────────────────────────────────────────────────────────
    # Standard letter sizes: S, M, L, XL, XXL
    if raw in LETTER_ORDER:
        return ("size", raw, float(LETTER_ORDER[raw]))

    # Dimensions: "60*100cm", "28*36cm", "25x28cm", "90*140cm"
    if re.search(r"\d+[*xX]\d+", raw):
        m = re.search(r"(\d+)[*xX](\d+)", raw)
        area = float(int(m.group(1)) * int(m.group(2))) if m else 0.0
        ltr = _area_to_letter(area)
        return ("size", ltr, float(LETTER_ORDER[ltr]))

    # Alphanumeric: S17, B75, B85
    if re.match(r"^[A-Za-z]+\d+$", raw):
        nums = list(map(int, re.findall(r"\d+", raw)))
        ltr = _numeric_to_letter(float(nums[0]) if nums else 0.0)
        return ("size", ltr, float(LETTER_ORDER[ltr]))

    # Pure numeric: 1, 9, 10, 11 … 110
    if re.match(r"^\d+$", raw):
        ltr = _numeric_to_letter(float(raw))
        return ("size", ltr, float(LETTER_ORDER[ltr]))

    return ("unknown", None, None)


def extract_step_from_desc(desc: str | None) -> float | None:
    """
    Extract product step/stage number from description text.
    Covers: 'Step 2', 'step3', 'Step1' patterns found in bottle nipple /
    toothbrush product lines.
    Returns stage number as float, or None if not found.
    """
    if not desc:
        return None
    m = re.search(r"(?i)\bstep\s*(\d+)", desc)
    if m:
        n = int(m.group(1))
        if 1 <= n <= 5:
            return float(n)
    m = re.search(r"(?i)giai\s*đo[aạ]n\s*(\d+)", desc)
    if m:
        n = int(m.group(1))
        if 1 <= n <= 5:
            return float(n)
    return None


# ── Load ──────────────────────────────────────────────────────────────────────
df = pl.read_parquet("./items.parquet")

# ── Build size lookup table ───────────────────────────────────────────────────
rows = []
for s in df["size"].unique().to_list():
    cat, ltr, key = parse_size(s)
    rows.append({
        "size_raw":     str(s) if s is not None else None,
        "_category":    cat,
        "_norm_letter": ltr,
        "_sort_key":    key,
    })

size_lut = pl.DataFrame(rows).with_columns(pl.col("_sort_key").cast(pl.Float64))

# ── Rename original 'size' column, join LUT ──────────────────────────────────
df = df.rename({"size": "size_raw"}).join(size_lut, on="size_raw", how="left")

# ── Extract step from description, override for matched items ─────────────────
desc_steps = [extract_step_from_desc(d) for d in df["description"].to_list()]
df = df.with_columns(pl.Series("_desc_step", desc_steps, dtype=pl.Float64))

# If description has a step number → force category='step' and use that value
df = df.with_columns([
    pl.when(pl.col("_desc_step").is_not_null())
      .then(pl.lit("step"))
      .otherwise(pl.col("_category"))
      .alias("_category"),

    pl.when(pl.col("_desc_step").is_not_null())
      .then(pl.col("_desc_step"))
      .otherwise(pl.col("_sort_key"))
      .alias("_sort_key"),
])

# ── Per-category output columns ───────────────────────────────────────────────
df = df.with_columns([
    # size: normalized S/M/L/XL/XXL for clothing items
    pl.when(pl.col("_category") == "size")
      .then(pl.col("_norm_letter"))
      .otherwise(None)
      .alias("size"),

    # step: max months from age-range size, OR stage number from description
    pl.when(pl.col("_category") == "step")
      .then(pl.col("_sort_key").cast(pl.Float64))
      .otherwise(None)
      .alias("step"),

    # piece: piece count
    pl.when(pl.col("_category") == "piece")
      .then(pl.col("_sort_key").cast(pl.Float64))
      .otherwise(None)
      .alias("piece"),
])

# ── Value columns ─────────────────────────────────────────────────────────────
# size_value: fixed S=1, M=2, L=3, XL=4, XXL=5
df = df.with_columns(
    pl.when(pl.col("_category") == "size")
      .then(pl.col("_sort_key").cast(pl.Int32))
      .otherwise(None)
      .alias("size_value")
)

# step_value: the stage number itself (1–5) — it is already the ordinal
df = df.with_columns(
    pl.col("step").cast(pl.Int32).alias("step_value")
)

# piece_value: dense rank (1 = smallest) across piece items
ranked_piece = (
    df.filter(pl.col("_category") == "piece")
      .with_columns(
          pl.col("piece")
            .rank(method="dense", descending=False)
            .cast(pl.Int32)
            .alias("piece_value")
      )
      .select(["item_id", "piece_value"])
)
df = df.join(ranked_piece, on="item_id", how="left")

# ── Print summary tables ──────────────────────────────────────────────────────
SEP = "=" * 72

# SIZE
print(f"\n{SEP}\n  SIZE  (all normalized to S/M/L/XL/XXL)\n{SEP}")
size_tbl = (
    df.filter(pl.col("_category") == "size")
      .select(["size_raw", "size", "size_value"])
      .unique()
      .sort("size_value", nulls_last=True)
)
print(f"  {'size_raw':<45} {'size':>6}  {'size_value':>10}")
print(f"  {'-'*45} {'-'*6}  {'-'*10}")
for r in size_tbl.iter_rows(named=True):
    print(f"  {str(r['size_raw']):<45} {str(r['size']):>6}  {str(r['size_value']):>10}")

# STEP
print(f"\n{SEP}\n  STEP  (stage 1–5 from product description only)\n{SEP}")
step_tbl = (
    df.filter(pl.col("_category") == "step")
      .select(["size_raw", "step", "step_value"])
      .unique()
      .sort("step_value", nulls_last=True)
)
print(f"  {'size_raw':<45} {'step':>8}  {'step_value':>10}")
print(f"  {'-'*45} {'-'*8}  {'-'*10}")
for r in step_tbl.iter_rows(named=True):
    print(f"  {str(r['size_raw']):<45} {str(r['step']):>8}  {str(r['step_value']):>10}")

# PIECE
print(f"\n{SEP}\n  PIECE\n{SEP}")
piece_tbl = (
    df.filter(pl.col("_category") == "piece")
      .select(["size_raw", "piece", "piece_value"])
      .unique()
      .sort("piece_value", nulls_last=True)
)
print(f"  {'size_raw':<50} {'piece':>7}  {'piece_value':>11}")
print(f"  {'-'*50} {'-'*7}  {'-'*11}")
for r in piece_tbl.iter_rows(named=True):
    print(f"  {str(r['size_raw']):<50} {str(r['piece']):>7}  {str(r['piece_value']):>11}")

# UNKNOWN
print(f"\n{SEP}\n  UNKNOWN\n{SEP}")
for r in df.filter(pl.col("_category") == "unknown").select("size_raw").unique().iter_rows():
    print(f"  {r[0]}")

# Description-step hits
desc_hits = df.filter(pl.col("_desc_step").is_not_null())
print(f"\n{SEP}\n  STEP FROM DESCRIPTION  ({desc_hits.height} items matched)\n{SEP}")
print(desc_hits.select(["item_id", "size_raw", "_desc_step", "step_value"]).head(10))

# ── Save ──────────────────────────────────────────────────────────────────────
final = df.drop(["_category", "_norm_letter", "_sort_key", "_desc_step"])
final.write_parquet("./items_with_size_parsed.parquet")
print(f"\n{SEP}")
print(f"  Saved → items_with_size_parsed.parquet")
print(f"  Shape : {final.shape}")
print(f"  Cols  : {final.columns}")
print(SEP)

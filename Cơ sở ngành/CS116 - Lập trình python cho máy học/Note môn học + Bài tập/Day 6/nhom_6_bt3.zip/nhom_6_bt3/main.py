import streamlit as st
import polars as pl
from score import build_similar_score_expression

st.title("Item Matcher — Similarity Score")

# ── Data loading ──────────────────────────────────────────────────────────────

@st.cache_data
def load_items():
    return pl.read_parquet("./items_with_size_parsed.parquet")

@st.cache_data
def load_transactions():
    return pl.read_parquet("./transactions-2025-12.parquet")

df_items = load_items()
df_trans = load_transactions()

item_id_col = "item_id"

# ── Sidebar: item selector ────────────────────────────────────────────────────
st.sidebar.header("Query item")

sample_df = df_items.sample(n=min(200, df_items.height), seed=42).select(
    [
        pl.col(item_id_col),
        pl.col("brand"),
        pl.col("category"),
        pl.col("price").cast(pl.Float64),
    ]
)

sample_rows = sample_df.to_dicts()

label_to_id = {
    (
        f"{r['item_id']} | {r['brand'] or 'N/A'} | {r['category'] or 'N/A'} | {r['price']:.2f}"
        if r["price"] is not None
        else f"{r['item_id']} | {r['brand'] or 'N/A'} | {r['category'] or 'N/A'} | N/A"
    ): r["item_id"]
    for r in sample_rows
}

selected_label = st.sidebar.selectbox("Or choose from sample", options=list(label_to_id.keys()))
_dropdown_id = label_to_id[selected_label]

k = st.sidebar.number_input("Top K matches", min_value=1, max_value=500, value=100, step=1)

# ── Show selected item info ───────────────────────────────────────────────────
pasted_id = st.text_input("Query item ID", value="0006040000126", placeholder="Paste an item_id here…").strip()

if pasted_id and pasted_id in df_items[item_id_col].to_list():
    selected_item_id = pasted_id
else:
    if pasted_id and pasted_id not in df_items[item_id_col].to_list():
        st.warning(f"Item ID `{pasted_id}` not found — using sidebar dropdown.")
    selected_item_id = _dropdown_id

input_row = df_items.filter(pl.col(item_id_col) == selected_item_id)
st.dataframe(input_row, use_container_width=True)

# ── Score ─────────────────────────────────────────────────────────────────────
if st.button("Find similar items"):
    with st.spinner("Computing similarity scores…"):
        score_expr, co_buy_stats = build_similar_score_expression(
            df_items, df_trans, selected_item_id
        )

        results = (
            df_items
            .filter(pl.col(item_id_col) != selected_item_id)
            .join(co_buy_stats, on=item_id_col, how="left")
            .with_columns(score_expr)
            .sort("similar_score", descending=True)
            .head(int(k))
        )

    if results.height == 0:
        st.info("No matches found.")
    else:
        # Show score breakdown columns first
        display_cols = (
            ["item_id", "similar_score", "co_buy_count",
             "category_l1", "category_l2", "category_l3", "category",
             "brand", "price", "size", "size_value", "step", "step_value",
             "piece", "piece_value"]
        )
        # Keep only columns that actually exist
        display_cols = [c for c in display_cols if c in results.columns]

        st.write(f"### Top {results.height} similar items")
        st.dataframe(
            results.select(display_cols).with_columns(
                pl.col("price").cast(pl.Float64),
                pl.col("similar_score").round(4),
            ),
            use_container_width=True,
        )

        # Co-buy contribution breakdown
        with st.expander("Co-buy stats for this item"):
            co_buy_display = (
                co_buy_stats
                .join(df_items.select([item_id_col, "brand", "category", "price"]), on=item_id_col, how="left")
                .sort("co_buy_count", descending=True)
            )
            st.dataframe(co_buy_display.with_columns(pl.col("price").cast(pl.Float64)), use_container_width=True)

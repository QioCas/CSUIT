import polars as pl


def build_similar_score_expression(df_items, df_trans, target_id):
    # A. Tính co_buy_score: Tìm khách hàng đã mua X, sau đó đếm các món khác họ mua
    target_customers = df_trans.filter(pl.col("item_id") == target_id).select("customer_id").unique()
    co_buy_stats = (
        df_trans.join(target_customers, on="customer_id")
        .filter(pl.col("item_id") != target_id)
        .group_by("item_id")
        .count()
        .rename({"count": "co_buy_count"})
    )

    # B. Lấy thông số của sản phẩm đang xem (X)
    q_data = df_items.filter(pl.col("item_id") == target_id).to_dicts()[0]

    # C. Định nghĩa biểu thức Cat Score
    cat_score_expr = (
        pl.when(pl.col("category") == q_data["category"]).then(1.0)
        .when(pl.col("category_l3") == q_data["category_l3"]).then(0.5)
        .when(pl.col("category_l2") == q_data["category_l2"]).then(0.25)
        .when(pl.col("category_l1") == q_data["category_l1"]).then(0.125)
        .otherwise(0.01) # Rất thấp nếu không liên quan
    )

    # D. Định nghĩa hàm Decay Score (Size, Piece, Step)
    def get_decay_expr(q_val, col_name, w1, w2):
        if q_val is None:
            # Query item has no value → can't compare, no penalty for anyone
            return pl.lit(1.0)

        diff_x_a = (q_val - pl.col(col_name)).clip(0, None)
        diff_a_x = (pl.col(col_name) - q_val).clip(0, None)

        return (
            pl.when(pl.col(col_name).is_null())
            .then(0.001)  # Candidate missing a comparable field → heavy penalty
            .otherwise((-(w1 * diff_x_a + w2 * diff_a_x)).exp())
        )

    # E. Tổng hợp biểu thức tính Score cuối cùng
    # Công thức: Score = (CoBuy + 1) * Cat * Size * Piece * Step
    similar_score_expr = (
        (pl.col("co_buy_count").fill_null(0) + 1) *
        cat_score_expr *
        get_decay_expr(q_data.get("size_value"), "size_value", 1.5, 0.5) *
        get_decay_expr(q_data.get("piece_value"), "piece_value", 1.5, 0.5) *
        get_decay_expr(q_data.get("step_value"), "step_value", 1.5, 0.5)
    ).alias("similar_score")

    return similar_score_expr, co_buy_stats